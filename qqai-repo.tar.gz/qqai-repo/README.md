# QQ AI 群友 · arm64 / 无 root 部署套件

把一个 QQ 小号变成有"人设"、会读空气、能识图的 AI 群友。
**专为 arm64 + 非 root + 无 systemd 的环境写**（例如 Android 上的 Debian 用户态、proot 容器）。

> 上游组件全部为第三方开源项目，本套件只做**部署编排与踩坑修补**，不修改它们的功能逻辑：
> - [AstrBot](https://github.com/AstrBotDevs/AstrBot) —— LLM 管家（后台、插件、人格）
> - [NapCatQQ](https://github.com/NapNeko/NapCatQQ) —— QQ 协议端（OneBot v11）
> - [astrbot_plugin_group_chat_plus](https://github.com/Him666233/astrbot_plugin_group_chat_plus) —— 读空气插件
> - 人格卡、NapCat 反连配置模板来自 [make-your-qq-ai-group-member](https://github.com/mtshang/make-your-qq-ai-group-member)

## 运行架构

```
QQ 群/好友
   │ 消息
   ▼
QQ arm64（腾讯官方 deb，Electron）
   │ 被注入
   ▼
NapCat ── OneBot v11 反向 WS ──▶ AstrBot ──▶ 你的大模型 API
(:6099 WebUI)              (:6199)   (:6185 后台)
                                      └─ 插件 group_chat_plus（读空气）
```

配套还有一个 **Xvfb**（虚拟屏 `:99`）：QQ 是图形程序，没有显示服务就不启动。

## 环境要求

| 项 | 要求 |
|---|---|
| 架构 | aarch64 |
| 系统 | Debian 13 (trixie) / 能 `dpkg-deb`、`curl`、`xz` |
| root | **不需要**（脚本只往 `$BASE` 和几个软链位置写） |
| 磁盘 | 约 **3.5 GB**（QQ ~760 MB、依赖前缀 ~450 MB、AstrBot ~400 MB） |
| 内存 | 建议 ≥ 2 GB 可用 |
| 网络 | 能访问 Debian 源 / PyPI / GitHub（脚本带镜像轮换） |

## 一行安装（从本仓库拉取）

> 把下面 URL 里的 `<你>/<仓库>` 换成你自己的（上传到 GitHub 后）。

**方式 A：内联 key，全自动**

```bash
curl -fsSL https://raw.githubusercontent.com/<你>/<仓库>/main/bootstrap.sh | \
  LLM_API_KEY=sk-xxx LLM_API_BASE=https://api.deepseek.com/v1 \
  LLM_MODEL=deepseek-chat ADMIN_QQ=123456789 bash
```

国内的网络建议加镜像前缀（bootstrap 内部也会自动轮换）：

```bash
curl -fsSL https://ghproxy.net/https://raw.githubusercontent.com/<你>/<仓库>/main/bootstrap.sh | \
  LLM_API_KEY=sk-xxx ADMIN_QQ=123456789 bash
```

**方式 B：先看脚本再跑（更稳妥）**

```bash
git clone --depth 1 https://github.com/<你>/<仓库>.git
cd <仓库>
cp config.env.example config.env && vi config.env
bash install.sh
```

> 安全提醒：`curl | bash` 等于把所有权限交给脚本。不确定时用方式 B，
> 或者先 `curl -fsSLO .../bootstrap.sh` 下载下来读一遍再执行。

## 快速开始（本地已有本目录时）

```bash
# 1) 填配置（至少 API key 和管理员 QQ）
cp config.env.example config.env
vi config.env

# 2) 安装（拉依赖、装 QQ、注入 NapCat、装 AstrBot）
bash install.sh

# 3) 启动（安装脚本已自动放好 bot.sh 等运行文件）
bash "$BASE/bot.sh" start

# 4) 注入人格卡（必须：否则机器人用的是空的 default 人格）
python3 tools/apply-persona.py
bash "$BASE/bot.sh" stop && bash "$BASE/bot.sh" start
```

启动后 `bot.sh status` 会打印局域网地址：

```
AstrBot 后台:  http://192.168.x.x:6185
NapCat 后台:   http://192.168.x.x:6099/webui
扫码页:        http://192.168.x.x:8901/
```

### 首次登录（必须人工做一次）

1. 手机浏览器打开扫码页 → 长按二维码 → 保存图片
2. **手机QQ（用小号！）** → 右上角 `+` → 扫一扫 → 右下角「相册」→ 选刚才那张
3. 登录成功后，把 `$BASE/napcat_onebot11.template.json` 里的
   `network.websocketClients` 写进
   `$BASE/QQ/resources/app/app_launcher/napcat/config/onebot11_<小号QQ>.json`
   （该文件是登录后才会生成的，所以只能登录后再写）
4. 重启协议端：`bash $BASE/bot.sh stop && bash $BASE/bot.sh start`

> 扫码页会自动维持"新鲜二维码"：每次打开都会检查码的年龄，超过 80 秒就自动重启 QQ 换一张，
> 所以你随时打开都是有效码。

## 目录说明

```
qqai-arm64-kit/
├── install.sh                  一键安装（6 步，可重复执行）
├── config.env.example          配置样例（key / QQ / 镜像）
├── src/
│   ├── fakelink.c              ★ 关键垫片：绕过"禁硬链接 + 禁 setuid"
│   ├── bot.sh                  start / stop / status / logs
│   ├── llm-relay.py            模型接口重试中转（上游建连抖动时用）
│   └── qr_server.py            自动刷新二维码的页面
├── tools/
│   ├── install-deps.py         无 root 安装 Debian 包进前缀目录
│   └── apply-persona.py        把人格卡写入 AstrBot 并绑定为默认
├── conf/
│   ├── cmd_config.json         AstrBot 主配置（已脱敏，占位符待替换）
│   ├── plugin_group_chat_plus.json  读空气插件配置（已调好的默认值）
│   ├── napcat_onebot11.json    NapCat 反连模板
│   └── persona_dafeiyu.md      「小鲸鱼」人格卡（上游 MIT，仅作示例）
└── docs/
    └── PITFALLS.md             ★ 十个坑与解法（强烈建议先读）
```

## 常用命令

```bash
bash $BASE/bot.sh start          # 启动全部
bash $BASE/bot.sh stop           # 全部停止
bash $BASE/bot.sh status         # 端口/进程/地址
bash $BASE/bot.sh logs 80        # AstrBot + 中转的最近日志
```

## 安全提醒

- `config.env` 里有 API key，**不要提交到任何仓库**；本套件不含真实 key。
- AstrBot 后台默认监听 `0.0.0.0`（为了手机浏览器能打开），**同局域网内可见**。
  在公共网络里用请改回 `127.0.0.1` 并走 SSH 隧道。
- 首次登录后立刻在后台把密码改成自己的（`config.env` 里的是初始值）。

## 关于人格卡

`conf/persona_dafeiyu.md` 是上游
[make-your-qq-ai-group-member](https://github.com/mtshang/make-your-qq-ai-group-member)
（MIT License, © 2026 mtshang）自带的示例人格，随包只为"开箱有性格"。
想换成自己的人格：改这个 markdown（或换 `PERSONA_ID`），重跑 `tools/apply-persona.py`。

> 注意：人格卡必须**通过 API 写入**（`apply-persona.py` 就是这么做的）。
> 直接 `INSERT INTO personas` 在部分版本会被判为非法行、重启后失效。

## 排障

先读 [`docs/PITFALLS.md`](docs/PITFALLS.md)，那里记录了本项目在 aarch64 沙箱里
真实撞到的十个坑（硬链接、setuid、/dev/shm、中文路径、pip SSL、日志爆盘……）与对应解法。
