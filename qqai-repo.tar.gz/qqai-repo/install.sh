#!/bin/bash
# QQ AI 群友 —— arm64 / 无 root 环境安装脚本
# 全程不碰系统目录（除了几个必要的软链），所有产物落在 $BASE 下，删目录即回滚。
#
# 用法：
#   cp config.env.example config.env   # 填 API key / QQ 号
#   bash install.sh
#
# 脚本按"我们实际验证通过"的顺序执行；每步都可单独重跑（幂等优先）。
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
# 配置来源：优先 config.env；没有但给了 LLM_API_KEY 时，用环境变量直接生成
if [ ! -f "$HERE/config.env" ]; then
  if [ -n "${LLM_API_KEY:-}" ]; then
    cp -f "$HERE/config.env.example" "$HERE/config.env"
    python3 - "$HERE/config.env" <<'PYGEN'
import os, re, sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
for k in ('LLM_API_KEY', 'LLM_API_BASE', 'LLM_MODEL', 'LLM_PROVIDER_ID',
          'ADMIN_QQ', 'DASHBOARD_PASSWORD', 'BASE'):
    v = os.environ.get(k, '')
    if v:
        s = re.sub(rf'^{k}=.*$', f'{k}={v}', s, flags=re.M)
open(p, 'w', encoding='utf-8').write(s)
print('  已根据环境变量生成 config.env')
PYGEN
  else
    echo "缺少 config.env。两种做法："
    echo "  a) cp config.env.example config.env 然后填写"
    echo "  b) 直接内联：LLM_API_KEY=sk-xxx ADMIN_QQ=123456 bash install.sh"
    exit 1
  fi
fi
set -a; . "$HERE/config.env"; set +a

# 后台密码：未设置则生成随机密码（避免仓库里出现弱默认值）
if [ -z "${DASHBOARD_PASSWORD:-}" ]; then
  DASHBOARD_PASSWORD=$(python3 -c "import secrets,string;a=string.ascii_letters+string.digits;print(''.join(secrets.choice(a) for _ in range(16)))")
  printf '\nDASHBOARD_PASSWORD=%s\n' "$DASHBOARD_PASSWORD" >> "$HERE/config.env"
  echo "已生成 AstrBot 后台随机密码，并写入 config.env"
fi

BASE="${BASE:-/opt/qqai}"
PREFIX="$BASE/prefix"
MIRROR="${DEBIAN_MIRROR:-https://mirrors.aliyun.com/debian}"
GH_MIRRORS=(${GH_MIRRORS:-https://ghproxy.net/ https://ghfast.top/ https://github.moeyy.xyz/})
export LD_LIBRARY_PATH="$PREFIX/usr/lib/aarch64-linux-gnu"

log() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[警告] %s\033[0m\n' "$*"; }

# 下载，自动轮换 GitHub 镜像前缀
dl_gh() {
  local url="$1" out="$2"
  for m in "${GH_MIRRORS[@]}"; do
    if curl -fsSL --connect-timeout 20 -o "$out" "${m}${url}" 2>/dev/null \
       && [ -s "$out" ] && { ! file "$out" | grep -qi 'html\|text'; }; then
      echo "  镜像可用：$m"
      return 0
    fi
  done
  echo "  直连尝试：$url"
  curl -fsSL --connect-timeout 30 -o "$out" "$url"
}

step_preflight() {
  log "步骤 1/6 环境检查"
  [ "$(uname -m)" = "aarch64" ] || warn "当前架构 $(uname -m)，本脚本按 aarch64 写的，可能不适用"
  local miss=0
  for c in curl python3 dpkg-deb xz tar unzip; do
    command -v "$c" >/dev/null || { echo "  缺少命令：$c"; miss=1; }
  done
  [ $miss -eq 0 ] || { echo "请先补齐上面的命令（Debian: apt install curl python3 dpkg xz-utils tar unzip）"; exit 1; }
  id -u | grep -qx 0 && warn "检测到 root，本脚本也能跑，但会把文件放进 $BASE"
  mkdir -p "$BASE" "$BASE/home/run"
  echo "  安装根目录：$BASE"
}

step_deps() {
  log "步骤 2/6 安装系统库到前缀（无 root）"
  if [ -f "$PREFIX/usr/bin/Xvfb" ] && [ -f "$PREFIX/usr/lib/aarch64-linux-gnu/libgtk-3.so.0" ]; then
    echo "  已存在，跳过（想重装就删掉 $PREFIX 和 $BASE/debs）"
    return
  fi
  python3 "$HERE/tools/install-deps.py" --prefix "$PREFIX" --mirror "$MIRROR" \
    xvfb x11-xkb-utils libgtk-3-0t64 libnss3 libnspr4 libasound2t64 libgbm1 \
    libatk1.0-0t64 libatk-bridge2.0-0t64 libcups2t64 libdbus-1-3 libxkbcommon0 \
    libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libxext6 libx11-6 libxcb1 \
    libpango-1.0-0 libcairo2 libglib2.0-0t64 libexpat1 libgcrypt20 libsecret-1-0 \
    fontconfig fonts-dejavu-core dbus tcc libc6-dev
}

step_shim() {
  log "步骤 3/6 编译 link/setuid 垫片（关键：本环境禁硬链接）"
  local tcc="$PREFIX/usr/bin/tcc"
  [ -x "$tcc" ] || { echo "  找不到 tcc，先跑步骤 2"; exit 1; }
  "$tcc" -shared -nostdlib -fPIC -o "$BASE/fakelink.so" "$HERE/src/fakelink.c"
  echo "  已生成 $BASE/fakelink.so"
  # Xvfb 需要 XKB 数据 + 编译键盘映射时 exec 的绝对路径
  rm -rf /opt/xkbdata && cp -r "$PREFIX/usr/share/X11/xkb" /opt/xkbdata
  mkdir -p /var/lib/xkb /tmp/.X11-unix
  chmod 1777 /var/lib/xkb 2>/dev/null || true
  mkdir -p /usr/bin && cat > /usr/bin/xkbcomp <<EOF
#!/bin/sh
export LD_LIBRARY_PATH=$PREFIX/usr/lib/aarch64-linux-gnu:/usr/lib/aarch64-linux-gnu
exec $PREFIX/usr/bin/xkbcomp "\$@"
EOF
  chmod +x /usr/bin/xkbcomp
  echo "  已准备 /opt/xkbdata 与 /usr/bin/xkbcomp"
}

step_qq() {
  log "步骤 4/6 安装 QQ（arm64 官方包）"
  if [ -x "$BASE/QQ/qq" ]; then echo "  已存在，跳过"; return; fi
  local url="${QQ_DEB_URL:-}"
  if [ -z "$url" ]; then
    echo "  从 NapCat 官方安装脚本里解析当前 arm64 包地址…"
    url=$(curl -fsSL --connect-timeout 20 \
      https://raw.githubusercontent.com/NapNeko/NapCat-Installer/main/script/install.sh 2>/dev/null \
      | grep -oE 'https://qqdl[^"]*arm64\.deb' | head -1 || true)
  fi
  [ -n "$url" ] || { echo "  解析失败，请在 config.env 里手动指定 QQ_DEB_URL"; exit 1; }
  echo "  下载 $url"
  curl -fSL --retry 3 -o "$BASE/QQ.deb" "$url"
  rm -rf "$BASE/.qqtmp" && mkdir -p "$BASE/.qqtmp"
  dpkg-deb -x "$BASE/QQ.deb" "$BASE/.qqtmp"
  mv "$BASE/.qqtmp/opt/QQ" "$BASE/QQ"
  rm -rf "$BASE/.qqtmp" "$BASE/QQ.deb"
  echo "  QQ 就位：$BASE/QQ"
}

step_napcat() {
  log "步骤 5/6 注入 NapCat"
  local app="$BASE/QQ/resources/app"
  if [ -f "$app/loadNapCat.js" ]; then echo "  已注入，跳过"; return; fi
  dl_gh "https://github.com/NapNeko/NapCatQQ/releases/latest/download/NapCat.Shell.zip" "$BASE/NapCat.Shell.zip"
  unzip -q -o "$BASE/NapCat.Shell.zip" -d "$app/app_launcher/napcat"
  cat > "$app/loadNapCat.js" <<'EOF'
const path = require('node:path');
const { pathToFileURL } = require('node:url');
import(pathToFileURL(path.join(__dirname, 'app_launcher/napcat/napcat.mjs')).href);
EOF
  python3 - "$app/package.json" <<'PY'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d['main'] = './loadNapCat.js'
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
print("  package.json main ->", d['main'])
PY
  echo "  NapCat 注入完成"
}

step_astrbot() {
  log "步骤 6/6 安装 AstrBot"
  local py="$BASE/venv/bin/python"
  if [ ! -x "$py" ]; then
    python3 -m venv "$BASE/venv"
    "$BASE/venv/bin/pip" install -q --upgrade pip || true
  fi
  if [ ! -x "$BASE/venv/bin/astrbot" ]; then
    echo "  安装 AstrBot（优先 uv，失败回退 pip）"
    if ! command -v uv >/dev/null; then
      "$BASE/venv/bin/pip" install -q --break-system-packages uv >/dev/null 2>&1 || true
    fi
    if command -v uv >/dev/null; then
      UV_DEFAULT_INDEX="${PYPI_INDEX:-https://mirrors.aliyun.com/pypi/simple/}" \
        uv pip install --python "$py" astrbot
    else
      warn "没有 uv，直接用 pip（若报 OSError: [Errno 38]，说明该环境 SSL 层有问题，需手动装 uv）"
      "$BASE/venv/bin/pip" install -i "${PYPI_INDEX:-https://mirrors.aliyun.com/pypi/simple/}" astrbot
    fi
  fi
  mkdir -p "$BASE/astrbot"
  ( cd "$BASE/astrbot" && ASTRBOT_ROOT="$BASE/astrbot" "$BASE/venv/bin/astrbot" init -y ) || true

  echo "  铺配置模板"
  python3 - "$HERE" "$BASE" <<'PY'
import json, io, os, sys
here, base = sys.argv[1], sys.argv[2]
data = os.path.join(base, 'astrbot', 'data')
fin = lambda p: json.load(io.open(p, encoding='utf-8-sig'))
fout = lambda p, d: json.dump(d, io.open(p, 'w', encoding='utf-8-sig'), ensure_ascii=False, indent=2)

cfg = fin(os.path.join(here, 'conf', 'cmd_config.json'))
cfg['provider_sources'][0]['api_base'] = os.environ.get('LLM_API_BASE', cfg['provider_sources'][0]['api_base'])
cfg['provider_sources'][0]['key'] = [os.environ.get('LLM_API_KEY', '')]
cfg['provider'][0]['model'] = os.environ.get('LLM_MODEL', cfg['provider'][0]['model'])
cfg['provider'][0]['id'] = os.environ.get('LLM_PROVIDER_ID', cfg['provider'][0]['id'])
cfg['agent_runner']['config']['model']['provider_id'] = cfg['provider'][0]['id']
admin = os.environ.get('ADMIN_QQ', '').strip()
cfg['admins_id'] = [admin] if admin else []
cfg['dashboard']['password_change_required'] = False
fout(os.path.join(data, 'cmd_config.json'), cfg)

plug = fin(os.path.join(here, 'conf', 'plugin_group_chat_plus.json'))
plug['image_to_text_provider_id'] = cfg['provider'][0]['id']
fout(os.path.join(data, 'config', 'astrbot_plugin_group_chat_plus_config.json'), plug)

nap = fin(os.path.join(here, 'conf', 'napcat_onebot11.json'))
fout(os.path.join(base, 'napcat_onebot11.template.json'), nap)
print("  cmd_config / 插件配置 已生成")
PY

  echo "  安装读空气插件"
  if [ ! -f "$BASE/astrbot/data/plugins/astrbot_plugin_group_chat_plus/main.py" ]; then
    dl_gh "https://github.com/Him666233/astrbot_plugin_group_chat_plus/archive/refs/heads/main.zip" "$BASE/plugin.zip"
    rm -rf "$BASE/.plug" && mkdir -p "$BASE/.plug"
    unzip -q -o "$BASE/plugin.zip" -d "$BASE/.plug"
    mv "$BASE/.plug"/astrbot_plugin_group_chat_plus-* "$BASE/astrbot/data/plugins/astrbot_plugin_group_chat_plus"
    rm -rf "$BASE/.plug" "$BASE/plugin.zip"
  fi
  echo "  插件就位"
}

step_runtime() {
  log "步骤 7/7 安装运行脚本"
  cp -f "$HERE/src/bot.sh" "$HERE/src/llm-relay.py" "$HERE/src/qr_server.py" "$BASE/"
  chmod +x "$BASE/bot.sh"
  cp -f "$HERE/config.env" "$BASE/config.env"
  echo "  已放置：$BASE/bot.sh / llm-relay.py / qr_server.py / config.env"
}

step_preflight
step_deps
step_shim
step_qq
step_napcat
step_astrbot
step_runtime

log "安装完成"
cat <<EOF

下一步：
  2) bash $BASE/bot.sh start         # 起 Xvfb + 中转 + 扫码页 + QQ + AstrBot
  3) 浏览器打开 http://<本机局域网IP>:8901/ 扫码登录小号
  4) AstrBot 起好后注入人格卡（必须做，否则用的是空的 default 人格）：
       python3 $HERE/tools/apply-persona.py
       bash $BASE/bot.sh stop && bash $BASE/bot.sh start    # 重启生效
     AstrBot 后台 http://<本机局域网IP>:6185
     用户名 astrbot   密码 ${DASHBOARD_PASSWORD}

注意：napcat 的反连配置要在登录后写进
  $BASE/QQ/resources/app/app_launcher/napcat/config/onebot11_<小号>.json
用的是 $BASE/napcat_onebot11.template.json 里的 network.websocketClients。
EOF
