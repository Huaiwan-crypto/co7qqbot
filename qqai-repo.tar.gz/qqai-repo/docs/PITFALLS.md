# 十个真实的坑（arm64 / 无 root / f2fs 沙箱环境）

这些不是"可能会遇到的问题"，而是本项目在这台机器上**逐个撞到并修掉**的。
每条都给了症状 → 定位方法 → 解法，方便你在别的环境里对号入座。

---

## 1. 硬链接被禁 → Xvfb 起不来（最难的一个）

**症状**

```
(EE) Fatal server error:
(EE) Linking lock file (/tmp/.X99-lock) in place failed: Permission denied
```

`-nolock` 也救不了：`Warning: the -nolock option can only be used by root`。

**定位**

```bash
cd /tmp && touch a && ln a b        # Permission denied  → 整个文件系统禁硬链接（f2fs + SELinux）
```

Xorg 建锁文件、以及编译键盘映射时都用 `link()`，失败即致命退出。

**解法**

`src/fakelink.c`：LD_PRELOAD 一个垫片，`link()/linkat()` **先试真实现，失败则退化为"复制文件"**。

```bash
tcc -shared -nostdlib -fPIC -o fakelink.so fakelink.c
LD_PRELOAD=./fakelink.so Xvfb :99 -screen 0 1280x800x24
```

> 关键点：**不能简单 return 0**。第一版就是把 link 假成成功，
> 结果 Xvfb "链好"了文件却不存在，读回时失败 → `XKB: Failed to compile keymap`。
> 必须真实复制出文件。

---

## 2. setuid 被拒 → Xorg 的子进程静默 `_exit(127)`

**症状**：Xvfb 过了锁文件这关，但 `xkbcomp` 永远不被调用，日志只有

```
XKB: Failed to compile keymap
Keyboard initialization failed.
```

**定位**：`strace -f -o st.log Xvfb ...`，看到子进程只做了三件事就消失：

```
setgid(getgid())  = 10421
（没有 setuid）
exit_group(127)
```

对照 Xorg 源码 `os/utils.c` 的 `System()`：

```c
if (setgid(getgid()) == -1) _exit(127);
if (setuid(getuid()) == -1) _exit(127);   // ← 沙箱在这里返回 -1
execl("/bin/sh", "sh", "-c", command, NULL);
```

**解法**：同一份垫片里把 `setuid/setgid/seteuid/setegid` 变成"直接成功"。
非特权用户下这两步本来也没有实际作用。

---

## 3. `/dev/shm` 不存在 → Electron 直接 FATAL

**症状**

```
FATAL:base/memory/platform_shared_memory_region_posix.cc:219]
This is frequently caused by incorrect permissions on /dev/shm
```

**解法**（二选一）

- 能建目录就建：`mkdir -p /dev/shm && chmod 1777 /dev/shm`
- 建不了（本项目的情况）：给 QQ 加 `--disable-dev-shm-usage`

---

## 4. 中文路径 → X 服务器拒绝启动

**症状**

```
Command line argument number 6 contains unprintable characters
(EE) X server aborted because of unsafe environment
```

Xorg 会检查 argv 里是否有不可打印字符，UTF-8 中文直接触发。

**解法**：Xvfb 相关路径**全部用 ASCII**。

- QQ 安装目录放 `/opt/qqai/QQ`（不要放在 `~/某个中文目录/`）
- xkb 数据复制到 `/opt/xkbdata`，用 `-xkbdir /opt/xkbdata`

> 动态库仍在中文路径下也能工作（`LD_LIBRARY_PATH` 不受这个限制）。

---

## 5. `pip install` 报 `OSError: [Errno 38] Function not implemented`

**症状**：下载大包（numpy 等）后崩在 SSL socket 关闭：

```
File "ssl.py", line 1363, in _real_close
OSError: [Errno 38] Function not implemented
```

换镜像、`--no-cache-dir`、加 `--retries` 都无效。

**解法**：换 **uv**（Rust 实现，不经过 Python 的 ssl 层）——本项目所有 Python 依赖都是用它装的，稳定且快 3~5 倍。

```bash
pip install uv || <手动下载 uv 的 aarch64 wheel 并解出二进制>
uv pip install --python /path/to/venv/bin/python astrbot
```

实测：`pip` 两次都在 150+ 个包的中途挂掉；`uv` 一次装完 154 个包。

---

## 6. NapCat 日志把磁盘写到 33 GB 满

**症状**：磁盘 100%，Xvfb 被拖死，服务莫名退出。

**原因**：QQ 的 stdout 有海量调试输出（MMKV、crashpad、cpufreq…），
如果 `nohup ./qq > qq.log 2>&1` 一直留着，几小时就是几十 GB。

**解法**

```json
// napcat/config/napcat.json
{ "fileLog": true, "consoleLog": false, "fileLogLevel": "info" }
```

- 控制台关掉（`consoleLog: false`），日志走它自己的文件
- 启动时把 stdout 丢 `/dev/null`，或定期清空
- 本项目最终把 QQ 的 stdout 定向到 `/dev/null`，只保留 NapCat 的文件日志

---

## 7. 没有 root、没有 apt 索引，怎么装 GTK/X11 那一堆库

QQ 是 Electron 程序，`ldd ./qq` 会列出 25 个 `not found`（GTK3、NSS、X11、cups、dbus…）。

**解法**：`tools/install-deps.py`

1. 下载 Debian 的 `Packages.xz` 索引（约 10 MB）
2. 自己解析 `Depends` 算依赖闭包（本项目实测：9 个入口 → **204 个包 / 98 MB**）
3. `curl` 并发下载 `.deb`，`dpkg-deb -x` 解到前缀目录
4. 运行时 `LD_LIBRARY_PATH=$PREFIX/usr/lib/aarch64-linux-gnu`

这是"影子安装"，不注册进 dpkg，删目录即回滚。

---

## 8. 手机浏览器打不开 `127.0.0.1:6185`（一直转圈）

**症状**：后台页面永远转圈；但服务器上 `curl 127.0.0.1:6185` 秒回 200。

**原因**：沙箱的 `127.0.0.1` 是该应用私有的回环，手机上的其它 App 连不到。
（本项目一开始扫码页也是这个原因打不开。）

**解法**

1. 把服务绑到 `0.0.0.0`：
   ```json
   // AstrBot: data/cmd_config.json
   "dashboard": { "host": "0.0.0.0", "port": 6185 }
   ```
2. 用**局域网 IP** 访问：`http://192.168.x.x:6185`
3. 顺便打开访问日志 `dashboard.disable_access_log=false`，这样"请求有没有到达"一眼可见

---

## 9. WebUI 密码：环境变量不生效

**症状**：设了 `ASTRBOT_DASHBOARD_INITIAL_PASSWORD=<你的强密码>`，登录仍 401。

**原因**：这个变量**只在密码字段为空时**才被采用。第一次启动时 AstrBot 已经
自己生成了一个 24 位随机密码并写进配置，之后变量就被忽略。

**解法**（确定知道自己密码的那种）

按 `astrbot/core/utils/auth_password.py` 的格式直接写哈希：

```
pbkdf2_sha256$600000$<salt_hex>$<pbkdf2_hmac_sha256(password, salt, 600000).hex()>
```

```python
from astrbot.core.utils.auth_password import hash_dashboard_password, hash_md5_dashboard_password
d['dashboard']['pbkdf2_password'] = hash_dashboard_password('你的密码')
d['dashboard']['password']        = hash_md5_dashboard_password('你的密码')
d['dashboard']['password_change_required'] = False
```

---

## 10. 模型接口"建连抖动"（NAT64 环境）

**症状**：`curl` 请求上游 API 大量 `Recv failure: Connection reset by peer`，
但偶尔成功；且**成功之后复用连接就 100% 稳定**。

**定位**

- 出口是 IPv6（`240a:...`，移动网络），上游只有 A 记录 → 走 NAT64 转换，握手期不稳
- 对照：`api.deepseek.com` 正常 → 不是全局网络问题
- 复用连接实测 6/6 成功 → 问题只在"新建连接"

**解法**：`src/llm-relay.py` —— 在 AstrBot 与上游之间加一层本地中转：

- 建连失败自动重试（指数退避，上限 20 次）
- 成功后保持长连接复用（连接池）
- 支持 SSE 流式透传

AstrBot 的 `api_base` 指向 `http://127.0.0.1:8977/v1` 即可。
实测：直连 8 次成功 1 次 → 经中转 **5/5 成功**。

---

## 附：模型默认开"思考"会拖慢群聊

如果你用的模型默认输出 `reasoning_content`，群聊里既慢又费 token。
本项目实测可用参数（OpenAI 兼容请求体里加）：

```json
{ "thinking": { "type": "disabled" } }
```

配置位置：AstrBot `provider[].custom_extra_body`。
（另一个候选 `reasoning_effort: "none"` 也有效，`enable_thinking: false` 无效。）

---

## 11. 人格卡"写进去了却没生效"

**症状**：`personas` 表里明明有行、`cmd_config` 也绑了 id，但插件日志一直说
`已使用当前会话人格: default`，回复像通用客服。

**两种成因**

1. **直接 INSERT 数据库**：`personas` 表有 `folder_id`/`sort_order` 等字段，
   部分版本启动时会做一致性检查，手工插入的行会被判成非法而丢弃。
2. **绑定字段没改**：真正生效的是
   `cmd_config.json → agent_runner.config.persona.persona_id`，
   顶层的 `default_personality` 在新版里可能是 `null`，改它没用。

**解法**：走官方 API 写（`tools/apply-persona.py` 封装好了）

```
POST /api/auth/login        -> token
GET  /api/v1/personas       -> 现有列表
POST /api/v1/personas       -> 创建（persona_id / system_prompt / begin_dialogs）
```

然后把 `agent_runner.config.persona.persona_id` 改成同一个人格 id，**重启** AstrBot。
启动日志出现 `Loaded N personas.` 才算加载成功。

> 踩坑记录：本项目第一次是"以为写成功了"——实际那次脚本被自己的 `pgrep -f` 误杀，
> insert 根本没执行。所以**每次写库/写配置后都要回读验证**，别信命令没报错。
