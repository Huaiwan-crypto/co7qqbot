#!/usr/bin/env python3
"""把人格卡写入 AstrBot 并绑定为默认人格（走官方 WebUI API，不直接改库）。

为什么不直接 INSERT 数据库：AstrBot 的人格表有 folder_id / sort_order 等字段，
且版本间会迁移；走 API 才不会在升级/重启后被判成非法行。

前置：AstrBot 已在运行（WebUI 可访问）。
用法：
    python3 apply-persona.py                       # 读 config.env
    python3 apply-persona.py --file conf/persona_dafeiyu.md --persona-id 大肥鱼DeepSeek

退出码 0 = 已就绪（新建或已存在）；非 0 = 失败并打印原因。
"""
import argparse
import json
import os
import sys
import urllib.error
import urllib.request


def load_env():
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, "config.env"),
                 os.path.join(here, "..", "config.env"),
                 os.environ.get("QQAI_CONFIG", "")):
        if cand and os.path.isfile(cand):
            for line in open(cand, encoding="utf-8"):
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
            return


def api(base, path, token=None, body=None, method="GET"):
    url = base.rstrip("/") + path
    data = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=60) as r:
        raw = r.read()
    return json.loads(raw) if raw else {}


def main():
    load_env()
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=os.environ.get("ASTRBOT_URL", "http://127.0.0.1:6185"))
    ap.add_argument("--user", default=os.environ.get("DASHBOARD_USER", "astrbot"))
    ap.add_argument("--password", default=os.environ.get("DASHBOARD_PASSWORD", ""))
    ap.add_argument("--persona-id", default=os.environ.get("PERSONA_ID", "大肥鱼DeepSeek"))
    ap.add_argument("--file", default=None, help="人格卡 markdown 路径")
    a = ap.parse_args()
    if not a.password:
        print("[persona] 没有密码：请在 config.env 里设 DASHBOARD_PASSWORD，或用 --password 传入")
        return 2

    here = os.path.dirname(os.path.abspath(__file__))
    md = a.file or os.path.join(here, "..", "conf", "persona_dafeiyu.md")
    if not os.path.isfile(md):
        print(f"[persona] 找不到人格文件：{md}")
        return 2
    prompt = open(md, encoding="utf-8").read()

    dialogs = ["我今天去喝酒了", "上班也能喝 少喝两杯就行了", "华莱士不敢吃 吃一次拉一次",
               "完了 已经点了", "你到底是人是AI？", "我是DeepSeek 小鲸鱼，V我50解锁高级对话",
               "蓝色大肥鱼！", "才不是大肥鱼！是小鲸鱼！", "我要去KTV", "点一首 我隔着屏幕听"]

    print(f"[persona] 登录 {a.base}")
    tok = api(a.base, "/api/auth/login",
              body={"username": a.user, "password": a.password},
              method="POST")["data"]["token"]

    existing = {p["persona_id"] for p in api(a.base, "/api/v1/personas", tok)["data"]}
    if a.persona_id in existing:
        print(f"[persona] 已存在：{a.persona_id}（跳过创建）")
    else:
        body = {"persona_id": a.persona_id, "system_prompt": prompt,
                "begin_dialogs": dialogs, "tools": None, "skills": None,
                "custom_error_message": None, "folder_id": None, "sort_order": 0}
        try:
            api(a.base, "/api/v1/personas", tok, body=body, method="POST")
            print(f"[persona] 已创建：{a.persona_id}（{len(prompt)} 字 + {len(dialogs)} 条开场白）")
        except urllib.error.HTTPError as e:
            print(f"[persona] 创建失败 HTTP {e.code}: {e.read()[:200].decode('utf-8', 'ignore')}")
            return 1

    # 绑定为 agent_runner 的默认人格（改配置文件，需重启 AstrBot 生效）
    cfg_path = os.path.join(os.environ.get("BASE", "/opt/qqai"), "astrbot", "data", "cmd_config.json")
    if os.path.isfile(cfg_path):
        import io
        d = json.load(io.open(cfg_path, encoding="utf-8-sig"))
        d.setdefault("agent_runner", {}).setdefault("config", {}).setdefault("persona", {})["persona_id"] = a.persona_id
        json.dump(d, io.open(cfg_path, "w", encoding="utf-8-sig"), ensure_ascii=False, indent=2)
        print(f"[persona] 已绑定 agent_runner 默认人格 → {a.persona_id}")
        print("[persona] 请重启 AstrBot 生效：bash $BASE/bot.sh stop && bash $BASE/bot.sh start")
    else:
        print(f"[persona] 未找到 {cfg_path}，跳过配置文件绑定（可在 WebUI 里手动设为默认人格）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
