#!/usr/bin/env python3
"""在无 root 环境里，从 Debian 源把一批包"安装"进前缀目录。

用途：QQ 是 Electron 程序，需要 GTK3/X11/NSS 等一堆系统库；本机没有 root、
也没有 apt 索引，所以这里自己解析 Debian 的 Packages 索引算依赖闭包，
下载 .deb 后用 `dpkg-deb -x` 解到 prefix，运行时靠 LD_LIBRARY_PATH 生效。

用法：
    python3 install-deps.py --prefix /opt/qqai/prefix --mirror https://mirrors.aliyun.com/debian \
        xvfb libgtk-3-0t64 libnss3 libasound2t64 libgbm1 libatk-bridge2.0-0t64 \
        libcups2t64 libdbus-1-3 libxkbcommon0 tcc libc6-dev x11-xkb-utils

注意：
- 索引约 10 MB、xz 压缩，下载后缓存在 <prefix>/../Packages 里，重跑会复用。
- 只解包不注册到 dpkg，属于"影子安装"，删目录即回滚。
"""
import argparse
import os
import re
import subprocess
import sys
import urllib.request

PREFER_ALTS = ("t64",)  # 优先挑带 t64 的替代（Debian 13 的时间/兼容库改名）


class Index:
    def __init__(self, mirror, cache_dir):
        self.mirror = mirror.rstrip("/")
        self.cache = os.path.join(cache_dir, "Packages")
        self.pkgs = {}
        self.prov = {}
        if not os.path.exists(self.cache):
            self._fetch()
        self._parse()

    def _fetch(self):
        url = f"{self.mirror}/dists/trixie/main/binary-arm64/Packages.xz"
        xz = self.cache + ".xz"
        print(f"[deps] 下载索引 {url}")
        urllib.request.urlretrieve(url, xz)
        subprocess.run(["xz", "-dkf", xz], check=True)
        print(f"[deps] 索引就绪 {os.path.getsize(self.cache) // 1024 // 1024} MB")

    def _parse(self):
        cur = {}

        def flush():
            name = cur.get("Package")
            if not name:
                return
            self.pkgs[name] = {
                "version": cur.get("Version", ""),
                "depends": (cur.get("Depends", "") + "," + cur.get("Pre-Depends", "")),
                "filename": cur.get("Filename", ""),
                "size": int(cur.get("Size", "0") or 0),
            }
            for p in (cur.get("Provides", "") or "").split(","):
                p = p.strip().split("(")[0].strip()
                if p:
                    self.prov.setdefault(p, name)

        with open(self.cache, encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.strip() == "":
                    flush(); cur = {}; continue
                if line[0] in " \t" or ":" not in line:
                    continue
                k, v = line.split(":", 1)
                cur[k.strip()] = v.strip()
        flush()

    def deps_of(self, name):
        out = []
        for group in self.pkgs[name]["depends"].split(","):
            group = group.strip()
            if not group:
                continue
            alts = [a.strip() for a in group.split("|")]
            picked = None
            for alt in alts:
                m = re.match(r"^([A-Za-z0-9][A-Za-z0-9+.\-]*)", alt)
                if not m:
                    continue
                base = m.group(1)
                real = base if base in self.pkgs else self.prov.get(base)
                if real:
                    picked = real
                    if any(t in base for t in PREFER_ALTS):
                        break
            if picked:
                out.append(picked)
        return out

    def closure(self, roots):
        seen, stack = set(), list(roots)
        while stack:
            n = stack.pop()
            if n in seen or n not in self.pkgs:
                continue
            seen.add(n)
            stack.extend(self.deps_of(n))
        return seen


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", required=True)
    ap.add_argument("--mirror", default="https://mirrors.aliyun.com/debian")
    ap.add_argument("--jobs", type=int, default=8)
    ap.add_argument("packages", nargs="+")
    a = ap.parse_args()

    base = os.path.dirname(os.path.abspath(a.prefix))
    idx = Index(a.mirror, base)

    missing = [p for p in a.packages if p not in idx.pkgs]
    if missing:
        print(f"[deps] 索引里找不到这些包名（可能改名了）：{missing}")
    roots = [p for p in a.packages if p in idx.pkgs]
    cl = idx.closure(roots)
    total = sum(idx.pkgs[n]["size"] for n in cl)
    print(f"[deps] 闭包 {len(cl)} 个包，约 {total / 1e6:.0f} MB")

    debs = os.path.join(base, "debs")
    os.makedirs(debs, exist_ok=True)
    todo = []
    for n in sorted(cl):
        fn = os.path.basename(idx.pkgs[n]["filename"])
        path = os.path.join(debs, fn)
        if os.path.exists(path) and os.path.getsize(path) == idx.pkgs[n]["size"]:
            continue
        todo.append((n, idx.pkgs[n]["filename"], path))
    print(f"[deps] 需下载 {len(todo)} 个")

    procs = []
    for n, rel, path in todo:
        p = subprocess.Popen(["curl", "-sS", "--retry", "3", "--connect-timeout", "20",
                              "-o", path, f"{idx.mirror}/{rel}"])
        procs.append(p)
        if len(procs) >= a.jobs:
            for q in procs:
                q.wait()
            procs = []
    for q in procs:
        q.wait()

    print("[deps] 解包到前缀")
    for n in sorted(cl):
        deb = os.path.join(debs, os.path.basename(idx.pkgs[n]["filename"]))
        if os.path.exists(deb):
            subprocess.run(["dpkg-deb", "-x", deb, a.prefix], stderr=subprocess.DEVNULL)
    print(f"[deps] 完成 -> {a.prefix}")
    print(f"[deps] 运行时请设置：export LD_LIBRARY_PATH={a.prefix}/usr/lib/aarch64-linux-gnu")


if __name__ == "__main__":
    main()
