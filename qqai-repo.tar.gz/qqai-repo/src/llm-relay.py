#!/usr/bin/env python3
"""本地 LLM 中转：给抖动严重的上游建连加"重试 + 长连接复用"。

背景：某些环境下上游只有 IPv4 记录，而本机出口是 IPv6（走 NAT64 转换），新连接会大量被重置；
但只要连上，复用连接 6/6 稳定。AstrBot 直连会偶发失败，故在其与上游之间加这一层：
  AstrBot -> http://127.0.0.1:8977/v1 -> (重试中的长连接) -> https://你的上游/v1

特性：
- POST /v1/chat/completions、GET /v1/models 原样转发
- 建连失败自动重试（指数退避，上限 20 次）
- 复用 keep-alive 连接；响应体逐块流式回写（SSE 透传）
- 上游返回非 5xx 就原样交给调用方，不改写任何内容
"""
import http.client
import json
import socket
import ssl
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# 配置来源优先级：环境变量 > 同目录/上层 config.env > 默认值
def _load_env():
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, "config.env"),
                 os.path.join(here, "..", "config.env"),
                 os.environ.get("QQAI_CONFIG", "")):
        if cand and os.path.isfile(cand):
            for line in open(cand, encoding="utf-8"):
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
            break

_load_env()
import os as _os
from urllib.parse import urlparse as _urlparse

_base = _os.environ.get("LLM_API_BASE", "https://api.deepseek.com/v1")
_u = _urlparse(_base)
UPSTREAM_HOST = _u.hostname or "api.deepseek.com"
UPSTREAM_PORT = _u.port or (443 if _u.scheme != "http" else 80)
UPSTREAM_SCHEME = _u.scheme or "https"
LISTEN = ("127.0.0.1", int(_os.environ.get("LLM_RELAY_PORT", "8977")))
MAX_ATTEMPTS = 20
HOP_HEADERS = {"host", "connection", "keep-alive", "proxy-authenticate",
               "proxy-authorization", "te", "trailers", "transfer-encoding", "upgrade"}

_pool_lock = threading.Lock()
_pool = []          # 空闲的上游连接
_warm = {"ok": 0, "fail": 0}


def _new_conn(timeout=180):
    if UPSTREAM_SCHEME == "http":
        c = http.client.HTTPConnection(UPSTREAM_HOST, UPSTREAM_PORT, timeout=timeout)
    else:
        c = http.client.HTTPSConnection(UPSTREAM_HOST, UPSTREAM_PORT,
                                        timeout=timeout, context=ssl.create_default_context())
    c.connect()
    return c


def _take_conn():
    with _pool_lock:
        while _pool:
            return _pool.pop()
    return None


def _put_conn(c):
    with _pool_lock:
        if len(_pool) < 4:
            _pool.append(c)
            return
    try:
        c.close()
    except Exception:
        pass


def _call(method, path, body, headers, timeout=180):
    """带回退重试的上游调用；返回 (status, headers, file-like)"""
    last = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        conn = _take_conn()
        try:
            if conn is None:
                conn = _new_conn(timeout)
            conn.request(method, path, body=body, headers=headers)
            resp = conn.getresponse()
            return resp, conn
        except Exception as e:               # 建连/发送阶段失败 → 重试
            last = e
            _warm["fail"] += 1
            try:
                conn.close()
            except Exception:
                pass
            time.sleep(min(0.15 * attempt, 1.2))
    raise last


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("[relay] " + (fmt % args) + "\n")
        sys.stderr.flush()

    def _headers_to_upstream(self):
        out = {}
        for k, v in self.headers.items():
            if k.lower() in HOP_HEADERS:
                continue
            out[k] = v
        return out

    def _proxy(self, method):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else None
        headers = self._headers_to_upstream()
        try:
            resp, conn = _call(method, self.path, body, headers)
            _warm["ok"] += 1
        except Exception as e:
            msg = json.dumps({"error": {"message": f"relay: upstream unreachable after {MAX_ATTEMPTS} attempts: {e}",
                                        "type": "relay_error"}}).encode()
            self.send_response(502)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(msg)))
            self.end_headers()
            self.wfile.write(msg)
            return

        try:
            self.send_response(resp.status)
            cl = resp.getheader("Content-Length")
            ctype = resp.getheader("Content-Type") or "application/json"
            for k, v in resp.getheaders():
                if k.lower() in HOP_HEADERS or k.lower() in ("content-length", "content-type"):
                    continue
                self.send_header(k, v)
            self.send_header("Content-Type", ctype)
            if cl:
                self.send_header("Content-Length", cl)
            else:
                self.send_header("Transfer-Encoding", "chunked")
            self.end_headers()

            chunked = cl is None
            while True:
                data = resp.read(4096)
                if not data:
                    break
                if chunked:
                    self.wfile.write(b"%x\r\n" % len(data) + data + b"\r\n")
                else:
                    self.wfile.write(data)
                self.wfile.flush()
            if chunked:
                self.wfile.write(b"0\r\n\r\n")
                self.wfile.flush()

            if cl is not None:
                _put_conn(conn)            # 定长响应读完了，连接可复用
            else:
                conn.close()
        except Exception:
            try:
                conn.close()
            except Exception:
                pass

    def do_POST(self):
        self._proxy("POST")

    def do_GET(self):
        self._proxy("GET")


if __name__ == "__main__":
    srv = ThreadingHTTPServer(LISTEN, Handler)
    srv.daemon_threads = True
    print(f"relay listening on http://{LISTEN[0]}:{LISTEN[1]}  ->  {UPSTREAM_SCHEME}://{UPSTREAM_HOST}:{UPSTREAM_PORT}", flush=True)
    srv.serve_forever()
