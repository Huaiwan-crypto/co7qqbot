/* link 垫片 v2：先尝试真实 linkat；失败（f2fs+SELinux 禁止硬链接）则退化为「复制文件」。
   为什么需要：Xvfb 建 /tmp/.X<n>-lock 与内部编译键映射都依赖 link()，本环境 link 一律 EACCES，
   而把 link 简单假成成功会让「读回刚链好的文件」失败。复制语义对这两处用途等价。
   不依赖 glibc 头文件，直接用 aarch64 系统调用号。*/

long syscall(long number, ...);

#define SYS_LINKAT 37
#define SYS_OPENAT 56
#define SYS_CLOSE  57
#define SYS_READ   63
#define SYS_WRITE  64
#define AT_FDCWD   (-100)

static int copy_file(const char *src, const char *dst)
{
    long in = syscall(SYS_OPENAT, AT_FDCWD, src, 0 /*O_RDONLY*/, 0);
    if (in < 0) return -1;
    /* O_WRONLY|O_CREAT|O_TRUNC = 1|0100|01000 */
    long out = syscall(SYS_OPENAT, AT_FDCWD, dst, 1 | 0100 | 01000, 0644);
    if (out < 0) { syscall(SYS_CLOSE, in); return -1; }
    char buf[8192];
    long n;
    int ok = 0;
    while ((n = syscall(SYS_READ, in, buf, sizeof buf)) > 0) {
        long off = 0;
        while (off < n) {
            long w = syscall(SYS_WRITE, out, buf + off, n - off);
            if (w <= 0) { ok = -1; break; }
            off += w;
        }
        if (ok) break;
    }
    syscall(SYS_CLOSE, in);
    syscall(SYS_CLOSE, out);
    return ok;
}

int linkat(int olddirfd, const char *oldpath, int newdirfd, const char *newpath, int flags)
{
    long r = syscall(SYS_LINKAT, olddirfd, oldpath, newdirfd, newpath, flags);
    if (r == 0) return 0;
    /* 仅在同一目录、非 AT_EMPTY_PATH 的普通情形下退化为复制 */
    if (copy_file(oldpath, newpath) == 0) return 0;
    return -1;
}

int link(const char *oldpath, const char *newpath)
{
    return linkat(AT_FDCWD, oldpath, AT_FDCWD, newpath, 0);
}

/* Xorg 的 System() 子进程会先 setgid(getgid()) 再 setuid(getuid())，
   任一失败即 _exit(127)，导致 xkbcomp 永远起不来。本环境是非特权用户，
   这两步本无实际作用，直接放行。 */
int setuid(unsigned int uid)
{
    (void)uid;
    return 0;
}

int setgid(unsigned int gid)
{
    (void)gid;
    return 0;
}

int seteuid(unsigned int uid)
{
    (void)uid;
    return 0;
}

int setegid(unsigned int gid)
{
    (void)gid;
    return 0;
}
