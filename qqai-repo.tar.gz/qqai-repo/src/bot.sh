#!/bin/bash
# QQ AI 群友：一键启停（无 systemd 环境，直接管裸进程）
# 依赖同目录或 $BASE 下的 config.env
#   ./bot.sh start | stop | status | logs [行数]
set -u

SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
for c in "$SELF_DIR/config.env" "${BASE:-}/config.env" /opt/qqai/config.env; do
  if [ -f "$c" ]; then set -a; . "$c"; set +a; break; fi
done
BASE="${BASE:-/opt/qqai}"
PREFIX="$BASE/prefix"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/aarch64-linux-gnu"

port_up() { python3 - "$1" <<'PY'
import socket, sys
s = socket.socket(); s.settimeout(1.5)
sys.exit(0 if s.connect_ex(('127.0.0.1', int(sys.argv[1]))) == 0 else 1)
PY
}

lan_ip() { python3 - <<'PY'
import socket
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(('8.8.8.8', 80))
    print(s.getsockname()[0]); s.close()
except Exception:
    print('127.0.0.1')
PY
}

start_xvfb() {
  if pgrep -f "Xvfb :99" >/dev/null 2>&1; then echo "  Xvfb      已运行"; return; fi
  rm -f /tmp/.X99-lock /tmp/.X11-unix/X99
  LD_PRELOAD="$BASE/fakelink.so" nohup "$PREFIX/usr/bin/Xvfb" :99 \
      -screen 0 1280x800x24 -xkbdir /opt/xkbdata -nolisten tcp > "$BASE/xvfb.log" 2>&1 &
  sleep 4
  if pgrep -f "Xvfb :99" >/dev/null; then echo "  Xvfb      已启动 (:99)"
  else echo "  Xvfb      启动失败，看 $BASE/xvfb.log"; fi
}

start_relay() {
  if [ "${USE_LLM_RELAY:-1}" != "1" ]; then echo "  llm-relay 已按配置跳过"; return; fi
  if port_up 8977; then echo "  llm-relay 已运行 (:8977)"; return; fi
  nohup python3 "$BASE/llm-relay.py" > "$BASE/llm-relay.log" 2>&1 &
  sleep 2; echo "  llm-relay 已启动 (:8977)"
}

start_qr() {
  if port_up 8901; then echo "  qr-server 已运行 (:8901)"; return; fi
  nohup python3 "$BASE/qr_server.py" > "$BASE/qr_server.log" 2>&1 &
  sleep 2; echo "  qr-server 已启动 (:8901)"
}

start_qq() {
  if pgrep -x qq >/dev/null; then echo "  QQ+NapCat 已运行"; return; fi
  ( cd "$BASE/QQ" && DISPLAY=:99 HOME="$BASE/home" XDG_RUNTIME_DIR="$BASE/home/run" \
    nohup ./qq --no-sandbox --disable-gpu --disable-dev-shm-usage > "$BASE/qq-out.log" 2>&1 & )
  sleep 20; echo "  QQ+NapCat 已启动"
}

start_astrbot() {
  if port_up 6185; then echo "  AstrBot   已运行 (:6185)"; return; fi
  ( cd "$BASE/astrbot" && ASTRBOT_ROOT="$BASE/astrbot" \
    ASTRBOT_DASHBOARD_INITIAL_PASSWORD="${DASHBOARD_PASSWORD:-}" \
    nohup "$BASE/venv/bin/astrbot" run > "$BASE/astrbot-run.log" 2>&1 & )
  sleep 25; echo "  AstrBot   已启动 (:6185)"
}

case "${1:-}" in
  start)
    echo "[启动]"; start_xvfb; start_relay; start_qr; start_qq; start_astrbot
    echo "[完成]"; exec "$0" status ;;
  stop)
    echo "[停止]"
    pkill -f 'venv/bin/astrbot run' 2>/dev/null && echo "  AstrBot   已停"
    pgrep -x qq | xargs -r kill 2>/dev/null && echo "  QQ+NapCat 已停"
    sleep 2
    pkill -f 'qr_server.py' 2>/dev/null && echo "  qr-server 已停"
    pkill -f 'llm-relay.py' 2>/dev/null && echo "  llm-relay 已停"
    pkill -f 'Xvfb :99' 2>/dev/null && echo "  Xvfb      已停"
    echo "  （完成）" ;;
  status)
    IP=$(lan_ip); echo "[状态] 局域网 IP: $IP"
    if pgrep -x qq >/dev/null; then echo "  QQ+NapCat 运行中 ($(pgrep -xc qq) 进程)"
    else echo "  QQ+NapCat 未运行"; fi
    for p in 6185 6199 8977 8901 6099; do
      if port_up $p; then echo "  端口 $p  监听中"; else echo "  端口 $p  未监听"; fi
    done
    echo "  AstrBot 后台:  http://$IP:6185"
    echo "  NapCat 后台:   http://$IP:6099/webui"
    echo "  扫码页:        http://$IP:8901/" ;;
  logs)
    echo "=== AstrBot ==="; tail -n "${2:-20}" "$BASE/astrbot-run.log" 2>/dev/null
    echo "=== 中转 ==="; tail -n 10 "$BASE/llm-relay.log" 2>/dev/null ;;
  *)
    echo "用法: $0 {start|stop|status|logs [行数]}"; exit 1 ;;
esac
