#!/usr/bin/env python3
"""二维码服务：访问即返回"当前有效"的 QQ 登录二维码。

为什么需要：NapCat 的登录码约 2 分钟过期，而每次重出码要重启 QQ（约 30 秒）。
静态文件服务会给出过期图，于是这里在请求时判断文件年龄，过期就自动重启 QQ 等新码。

路由：
  /            说明页（内嵌二维码，2 分钟自动刷新）
  /qrcode.png  当前有效二维码（PNG，5 倍放大）
"""
import io
import os
import subprocess
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from PIL import Image

import os as _os

def _load_env():
    here = _os.path.dirname(_os.path.abspath(__file__))
    for cand in (_os.path.join(here, "config.env"),
                 _os.path.join(here, "..", "config.env"),
                 _os.environ.get("QQAI_CONFIG", "")):
        if cand and _os.path.isfile(cand):
            for line in open(cand, encoding="utf-8"):
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                _os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
            break

_load_env()
BASE = _os.environ.get("BASE", "/opt/qqai")
QR_SRC = _os.path.join(BASE, "QQ/resources/app/app_launcher/napcat/cache/qrcode.png")
QQ_DIR = _os.path.join(BASE, "QQ")
PREFIX = _os.path.join(BASE, "prefix")
HOME_DIR = _os.path.join(BASE, "home")
PORT = int(_os.environ.get("QR_PORT", "8901"))
MAX_AGE = 80          # 秒；超过就认为该换了
WAIT_NEW = 75         # 等新码最长秒数

_refresh_lock = None


def _qq_pids():
    out = subprocess.run(["pgrep", "-x", "qq"], capture_output=True, text=True).stdout
    return [int(x) for x in out.split()]


def _start_qq():
    env = dict(os.environ)
    env.update({
        "LD_LIBRARY_PATH": f"{PREFIX}/usr/lib/aarch64-linux-gnu",
        "DISPLAY": ":99",
        "HOME": HOME_DIR,
        "XDG_RUNTIME_DIR": os.path.join(HOME_DIR, "run"),
    })
    subprocess.Popen(["./qq", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage"],
                     cwd=QQ_DIR, env=env,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True)


def _age():
    try:
        return time.time() - os.path.getmtime(QR_SRC)
    except OSError:
        return 1e9


def fresh_qr_png():
    """返回 (png_bytes, 生成时间)。必要时重启 QQ 等新码。"""
    global _refresh_lock
    import threading
    if _refresh_lock is None:
        _refresh_lock = threading.Lock()

    if _age() > MAX_AGE:
        with _refresh_lock:
            if _age() > MAX_AGE:            # 双检，避免并发重复重启
                old = _age()
                for pid in _qq_pids():
                    try:
                        os.kill(pid, 15)
                    except OSError:
                        pass
                time.sleep(3)
                _start_qq()
                deadline = time.time() + WAIT_NEW
                while time.time() < deadline:
                    if _age() < old - 5:    # 文件被刷新过
                        break
                    time.sleep(1)

    with open(QR_SRC, "rb") as f:
        raw = f.read()
    im = Image.open(io.BytesIO(raw)).convert("RGB")
    big = im.resize((im.width * 5, im.height * 5), Image.NEAREST)
    buf = io.BytesIO()
    big.save(buf, format="PNG")
    return buf.getvalue(), os.path.getmtime(QR_SRC)


HTML = """<!doctype html><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>QQ 登录二维码</title>
<style>
 html,body{margin:0;height:100%;background:#fff;display:flex;flex-direction:column;
   align-items:center;justify-content:center;font-family:system-ui,-apple-system,sans-serif}
 img{width:min(82vw,82vh);image-rendering:pixelated;padding:10px;background:#fff}
 p{color:#333;font-size:15px;margin:6px 14px;text-align:center;line-height:1.65}
 b{color:#0b6}
</style>
<p><b>长按二维码 → 保存图片</b><br>
手机QQ → 右上角 <b>+</b> → 扫一扫 → 右下角「相册」→ 选刚保存的图</p>
<img src="/qrcode.png?t=__T__" alt="QQ 登录二维码">
<p id="tip">此页每 60 秒自动换最新码；若提示过期，下拉刷新即可</p>
<script>
setTimeout(()=>location.reload(), 60000);
</script>
"""


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path.startswith("/qrcode.png"):
            png, mt = fresh_qr_png()
            age = int(time.time() - mt)
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(png)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-QR-Age", str(age))
            self.end_headers()
            self.wfile.write(png)
            return
        body = HTML.replace("__T__", str(int(time.time()))).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    srv.daemon_threads = True
    print(f"qr server on :{PORT}", flush=True)
    srv.serve_forever()
