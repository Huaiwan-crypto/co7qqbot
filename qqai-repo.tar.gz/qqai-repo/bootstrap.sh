#!/bin/bash
# 一行安装入口（给 README 里的 curl | bash 用）
#
# 用法 A（推荐，带 key 内联）：
#   curl -fsSL https://raw.githubusercontent.com/<你>/<仓库>/main/bootstrap.sh | \
#     LLM_API_KEY=sk-xxx ADMIN_QQ=123456 bash
#
# 用法 B（先下下来看看再跑）：
#   curl -fsSLO https://raw.githubusercontent.com/<你>/<仓库>/main/bootstrap.sh
#   less bootstrap.sh && bash bootstrap.sh
#
# 它做的事：换镜像下载仓库 tarball -> 校验 -> 解包到临时目录 -> 用环境变量生成 config.env -> 跑 install.sh
set -euo pipefail

REPO="${QQAI_REPO:-你的用户名/qqai-arm64-kit}"   # ← 上传后把这里改成 用户名/仓库名
REF="${QQAI_REF:-main}"
WORK="${TMPDIR:-/tmp}/qqai-bootstrap-$$"
TARBALL="$WORK.tar.gz"

GH_MIRRORS=(${GH_MIRRORS:-https://ghproxy.net/ https://ghfast.top/ https://github.moeyy.xyz/ https://gh-proxy.com/})

log()  { printf '\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[警告] %s\033[0m\n' "$*"; }

need() { command -v "$1" >/dev/null || { echo "缺少命令：$1"; exit 1; }; }
need curl; need tar

log "目标仓库：$REPO@$REF"

# 依次尝试：镜像 + 官方 codeload
try_urls=()
for m in "${GH_MIRRORS[@]}"; do
  try_urls+=("${m}https://github.com/${REPO}/archive/refs/heads/${REF}.tar.gz")
done
try_urls+=("https://codeload.github.com/${REPO}/tar.gz/refs/heads/${REF}")

ok=0
for u in "${try_urls[@]}"; do
  echo "  尝试 $u"
  if curl -fsSL --connect-timeout 20 --max-time 300 -o "$TARBALL" "$u" 2>/dev/null \
     && tar -tzf "$TARBALL" >/dev/null 2>&1; then
    ok=1; echo "  ✅ 下载成功"; break
  fi
done
[ $ok -eq 1 ] || { echo "全部下载源失败。请检查网络，或手动 clone：git clone https://github.com/$REPO"; exit 1; }

mkdir -p "$WORK"
tar -xzf "$TARBALL" -C "$WORK" --strip-components=1
log "解包到 $WORK"

# 用环境变量生成 config.env（有就跳过提问）
if [ -n "${LLM_API_KEY:-}" ]; then
  cp -f "$WORK/config.env.example" "$WORK/config.env"
  python3 - "$WORK/config.env" <<'PY'
import os, sys, re
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
mapping = {
    'LLM_API_KEY': os.environ.get('LLM_API_KEY', ''),
    'LLM_API_BASE': os.environ.get('LLM_API_BASE', ''),
    'LLM_MODEL': os.environ.get('LLM_MODEL', ''),
    'LLM_PROVIDER_ID': os.environ.get('LLM_PROVIDER_ID', ''),
    'ADMIN_QQ': os.environ.get('ADMIN_QQ', ''),
    'DASHBOARD_PASSWORD': os.environ.get('DASHBOARD_PASSWORD', ''),
    'BASE': os.environ.get('BASE', ''),
}
for k, v in mapping.items():
    if v:
        s = re.sub(rf'^{k}=.*$', f'{k}={v}', s, flags=re.M)
open(p, 'w', encoding='utf-8').write(s)
print("  已用环境变量生成 config.env")
PY
else
  warn "没有提供 LLM_API_KEY，安装到填配置那步会停下来"
fi

log "开始安装（可中断，重跑会跳过已完成步骤）"
cd "$WORK"
bash install.sh

log "完成"
echo "下一步：bash \$BASE/bot.sh start"
echo "临时目录保留在 $WORK（要清理就 rm -rf $WORK $TARBALL）"
